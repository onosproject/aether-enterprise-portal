import { Component } from '@angular/core';

@Component({
  selector: 'aep-graph',
  templateUrl: './graph.component.html',
  styleUrls: ['./graph.component.scss'],
})
export class GraphComponent {
  TabParentValue = ['bandwidth'];
  TabChildValue = ['1h'];
}
