import { Component } from '@angular/core';

@Component({
  selector: 'aep-delete-devices',
  templateUrl: './delete-devices.component.html',
  styles: [],
})
export class DeleteDevicesComponent {}
