import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// import { JoinerComponent } from './joiner.component';

@NgModule({
  declarations: [],
  imports: [CommonModule],
})
export class JoinerModule {}
