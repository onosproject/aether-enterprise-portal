/*
 * SPDX-FileCopyrightText: 2021-present Open Networking Foundation <info@opennetworking.org>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { Injectable } from '@angular/core';
// import { GlobalDataService } from 'src/app/services/global-data.service';

@Injectable({
  providedIn: 'root',
})
export class DeviceGroupsHelperService {
  // selectedSite: string = '';
  // constructor(public globalService: GlobalDataService) {}
  // getCurrentSite(): void {
  //   this.globalService.getSite().subscribe((data) => {
  //     this.selectedSite = data;
  //   });
  // }
  // addDevicetoDeviceGroup(): void {
  //   this.getCurrentSite();
  //   let siteID: string;
  //   this.globalService.totalConfig[0].sites.forEach((sitesConfig) => {
  //     siteID = sitesConfig['site-id'];
  //     if (this.selectedSite === siteID) {
  //       // sitesConfig['device-groups'].push(connectedDevice);
  //       // console.log(sitesConfig.devices)
  //     }
  //   });
  // }
}
